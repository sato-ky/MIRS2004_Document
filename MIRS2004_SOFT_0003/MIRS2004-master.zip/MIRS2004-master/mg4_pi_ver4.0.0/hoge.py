import numpy as np
a = 3
print(a)
