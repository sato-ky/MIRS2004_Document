#ifndef __TEST_MOTOR__
#define __TEST_MOTOR__

extern int main();

#endif
