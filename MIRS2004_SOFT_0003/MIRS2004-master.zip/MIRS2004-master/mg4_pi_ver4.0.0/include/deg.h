#ifndef __DEG__
#define __DEG__

extern int deg(int *p);

#endif
