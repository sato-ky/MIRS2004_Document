#ifndef __C_SEND__
#define __C_SEND__

extern void C_send(int mode);

#endif
